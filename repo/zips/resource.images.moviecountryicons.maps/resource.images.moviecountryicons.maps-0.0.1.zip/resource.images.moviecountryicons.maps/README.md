<h1>Country Icons: Maps</h1>

Maps icons for the Countries node in Movies. Maps courtesy of DJAISS, https://github.com/djaiss/mapsicon.

![screenshot] (http://i.imgur.com/RsUl7CK.jpg)